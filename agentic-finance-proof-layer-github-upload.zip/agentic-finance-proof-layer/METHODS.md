# Methods and Reproduction

## Purpose

The experiment demonstrates two narrow ideas: (1) checking two actions against the same stale budget snapshot can allow a hypothetical aggregate overspend, and (2) a basic hash-linked evidence record can make certain post-hoc modifications detectable.

## Run

```bash
python3 experiments/agent_policy_reference_test_audited.py
```

Python standard library only. The source fixes the pseudorandom seed at `20261013` and runs `10,000` generated scenarios. The script prints JSON and writes `agent_policy_reference_results_audited.json` beside itself.

## Interpretation

The model is an illustrative reference model, not a deployment test. It is not evidence that Agent Pass, Rooms, Warrant, PAS, or any live Sui contract behaves this way. In particular, it does not establish atomicity or concurrency behavior for any production system.

## Integrity

- Source SHA-256: `1b905eb8dee8d9bfe21846c8b36ee10bea346545d48dc0eadc2a2785da4ac71d`
- Published output SHA-256: `1bf39ed96ef9ed18dda318f3fcc619b35d2a7ad2fd7cc74cf35c47224d629910`

A matching hash establishes byte-for-byte identity with the named artifact only; it does not establish correctness or applicability to an external system.
