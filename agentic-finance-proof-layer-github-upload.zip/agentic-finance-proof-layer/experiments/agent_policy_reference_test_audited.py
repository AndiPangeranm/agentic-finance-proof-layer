#!/usr/bin/env python3
"""Deterministic reference-model experiment; not a test of Agent Pass or PAS."""
import json, random, statistics, hashlib, pathlib, copy
SEED = 20261013
TRIALS = 10_000
rng = random.Random(SEED)
naive_breaches = 0
naive_overspend_ratios = []
safe_breaches = 0
safe_accepted_counts = []
scenarios = []

# Explicit adversarial fixture: two individually permissible actions are checked against
# the same stale budget snapshot. This is a hypothetical vulnerable design.
budget, amounts = 1_000, [600, 600]
naive_accepted = [a for a in amounts if a <= budget]
naive_total = sum(naive_accepted)
safe_accepted, safe_total = [], 0
for amount in amounts:
    if amount <= budget and safe_total + amount <= budget:
        safe_accepted.append(amount)
        safe_total += amount
    # otherwise reject under the aggregate budget
assert naive_total == 1200 and naive_total > budget
assert safe_total == 600 and safe_total <= budget

for trial in range(TRIALS):
    b = rng.randint(1_000, 10_000)
    n = rng.randint(2, 20)
    reqs = [rng.randint(1, b) for _ in range(n)]

    # Vulnerable comparison model: every request independently checks against
    # the same pre-batch balance; no atomic aggregate reservation is applied.
    vulnerable_accepted = [x for x in reqs if x <= b]
    vulnerable_total = sum(vulnerable_accepted)
    if vulnerable_total > b:
        naive_breaches += 1
        naive_overspend_ratios.append((vulnerable_total - b) / b)

    # Safe reference model: deterministic serialized reservation of the total.
    accepted, spent = [], 0
    for x in reqs:
        if x <= b and spent + x <= b:
            accepted.append(x)
            spent += x
    if spent > b:
        safe_breaches += 1
    safe_accepted_counts.append(len(accepted))

    if trial < 5:
        scenarios.append({"trial": trial + 1, "budget": b, "requests": reqs,
                          "vulnerable_accepted_total": vulnerable_total,
                          "vulnerable_breach": vulnerable_total > b,
                          "safe_accepted_total": spent,
                          "safe_breach": spent > b})

assert safe_breaches == 0
assert naive_breaches > 0
# Minimal hash-linked evidence-log test. It checks linkage consistency only.
# There is no independently trusted terminal hash or expected event count.
def digest(obj):
    blob = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(blob).hexdigest()

def make_log(payloads):
    log, prev = [], "GENESIS"
    for payload in payloads:
        event_hash = digest({"payload": payload, "prev_hash": prev})
        log.append({"payload": payload, "prev_hash": prev, "hash": event_hash})
        prev = event_hash
    return log

def verify_log(log):
    prev = "GENESIS"
    for event in log:
        if event.get("prev_hash") != prev:
            return False
        if event.get("hash") != digest({"payload": event.get("payload"), "prev_hash": prev}):
            return False
        prev = event["hash"]
    return True

sample_log = make_log([
    {"seq": 1, "policy_version": "p1", "action": "transfer", "amount": 100, "decision": "allow"},
    {"seq": 2, "policy_version": "p1", "action": "transfer", "amount": 950, "decision": "deny"},
    {"seq": 3, "policy_version": "p1", "action": "revoke", "amount": 0, "decision": "allow"},
])
intact_log_verifies = verify_log(sample_log)
tampered_log = copy.deepcopy(sample_log)
tampered_log[1]["payload"]["decision"] = "allow"
tampered_record_detected = not verify_log(tampered_log)
omitted_event_detected = not verify_log([sample_log[0], sample_log[2]])
# These two limitations are expected: the verifier does not anchor the final hash
# and does not know the expected number of records.
tail_omission_not_detected = verify_log(sample_log[:-1])
rewritten_payloads = [
    {"seq": 1, "policy_version": "p1", "action": "transfer", "amount": 100, "decision": "allow"},
    {"seq": 2, "policy_version": "p1", "action": "transfer", "amount": 950, "decision": "allow"},
    {"seq": 3, "policy_version": "p1", "action": "revoke", "amount": 0, "decision": "allow"},
]
full_rewrite_without_trusted_anchor_accepted = verify_log(make_log(rewritten_payloads))
assert intact_log_verifies and tampered_record_detected and omitted_event_detected
assert tail_omission_not_detected and full_rewrite_without_trusted_anchor_accepted

results = {
  "experiment": "aggregate-budget-reference-model-v1",
  "scope": "synthetic reference model only; not Agent Pass, Rooms, Warrant, PAS, or any deployed contract",
  "seed": SEED,
  "trials": TRIALS,
  "explicit_fixture": {"budget": budget, "requests": amounts,
                        "vulnerable_accepted_total": naive_total,
                        "vulnerable_overspend": naive_total - budget,
                        "safe_accepted_total": safe_total,
                        "safe_rejected_requests": len(amounts) - len(safe_accepted)},
  "randomized_batch_test": {
    "request_count_per_trial": "uniform integer 2..20",
    "budget_per_trial": "uniform integer 1000..10000",
    "amount_per_request": "uniform integer 1..budget",
    "vulnerable_model_breach_trials": naive_breaches,
    "vulnerable_model_breach_rate": naive_breaches / TRIALS,
    "median_overspend_as_fraction_of_budget_when_breached": statistics.median(naive_overspend_ratios),
    "safe_reference_model_breach_trials": safe_breaches,
    "safe_reference_model_breach_rate": safe_breaches / TRIALS,
    "safe_model_median_accepted_actions": statistics.median(safe_accepted_counts)
  },
  "evidence_log_integrity_test": {
    "algorithm": "SHA-256 hash-linked records; deterministic Python JSON serialization with sorted keys and compact separators",
    "records_in_fixture": 3,
    "intact_log_verifies": intact_log_verifies,
    "tampered_record_detected": tampered_record_detected,
    "omitted_middle_event_detected": omitted_event_detected,
    "tail_omission_not_detected": tail_omission_not_detected,
    "full_rewrite_without_trusted_anchor_accepted": full_rewrite_without_trusted_anchor_accepted,
    "limitations": "Internal-consistency checks only. There is no independently trusted terminal hash or expected record count, so tail truncation and a self-consistent full rewrite can verify. The test does not prove authorship, event completeness, truth of payloads, or deployed-system security."
  },
  "first_five_scenarios": scenarios,
  "interpretation": "This demonstrates a generic stale-snapshot aggregate-budget failure mode in a deliberately vulnerable model and the invariant maintained by a serialized reference model. It is not a scheduler or network-concurrency simulation and does not show that any Sui product has this flaw or that the reference model is a production implementation."
}
out=pathlib.Path(__file__).with_name('agent_policy_reference_results_audited.json')
out.write_text(json.dumps(results, indent=2)+"\n")
print(json.dumps(results, indent=2))
print("RESULTS_SHA256", hashlib.sha256(out.read_bytes()).hexdigest())
